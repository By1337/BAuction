package org.by1337.api.world.entity;

public enum BInteractionHand {
    MAIN_HAND, OFF_HAND;
}

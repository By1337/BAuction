package org.by1337.api.chat.hover;

/**
 * Enum representing different types of hover events.
 */
public enum HoverEventType {
    SHOW_TEXT,
    //SHOW_ITEM,
    //SHOW_ENTITY,
    //SHOW_ACHIEVEMENT,
}

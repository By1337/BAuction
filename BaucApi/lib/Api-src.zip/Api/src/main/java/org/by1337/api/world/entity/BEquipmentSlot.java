package org.by1337.api.world.entity;

public enum BEquipmentSlot {
    MAINHAND,
    OFFHAND,
    FEET,
    LEGS,
    CHEST,
    HEAD
}

package org.by1337.api.inventory;

public interface FakeTitleFactory {
    FakeTitle get();
}

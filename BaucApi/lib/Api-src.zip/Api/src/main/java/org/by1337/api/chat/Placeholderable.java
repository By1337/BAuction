package org.by1337.api.chat;
@FunctionalInterface
public interface Placeholderable {
    String replace(String string);
}
